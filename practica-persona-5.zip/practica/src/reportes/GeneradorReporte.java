package reportes;

import docbuilder.CDocBuilder;
import reportes.builder.DocBuilderScript;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class GeneradorReporte {

    private static final String BUILDER_DIR =
            "C:/Program Files/ONLYOFFICE/DocumentBuilder";

    /**
     * Genera un PDF de reporte de paciente usando DocBuilderScript.
     */
    public static void generarPDF(
            String nombrePaciente,
            String semanaInicio,
            String semanaFin,
            String[][] estadisticas,
            String rutaImagen,
            String rutaSalida
    ) throws Exception {

        // 1. Construir el script con la clase fluida
        String script = new DocBuilderScript()
                .colorPrimario(0, 70, 127)               // azul corporativo
                .fuentes(40, 20, 28, 20)                 // título / sub / sección / tabla
                .cabecera(
                    "INFORME DE PACIENTE",
                    nombrePaciente,
                    semanaInicio,
                    semanaFin
                )
                .tablaEstadisticas("Estadísticas del período", estadisticas)
                .imagenGrafica("Gráfica de uso", rutaImagen, 15.0, 8.0)
                .build(rutaSalida);

        // 2. Guardar el script en un archivo temporal
        Path scriptTemp = Files.createTempFile("reporte_", ".docbuilder");
        Files.writeString(scriptTemp, script, StandardCharsets.UTF_8);
        System.out.println("Script generado:\n" + script); // útil para depurar

        // 3. Ejecutar con CDocBuilder
        CDocBuilder.initialize(BUILDER_DIR);
        CDocBuilder builder = new CDocBuilder();
        try {
            builder.run(scriptTemp.toString());
            System.out.println("✅ PDF generado en: " + rutaSalida);
        } finally {
            builder.destroy();
            CDocBuilder.dispose();
            Files.deleteIfExists(scriptTemp);
        }
    }

    // ── Ejemplo de uso ─────────────────────────────────────────────────────
    public static void main(String[] args) throws Exception {

        String[][] estadisticas = {
            {"Horas de uso diario (promedio)", "6.4 h"},
            {"Días activos",                   "18 / 21"},
            {"Sesiones completadas",           "54"},
            {"Adherencia al plan",             "86 %"},
            {"Alertas generadas",              "3"}
        };

        generarPDF(
            "Ana García López",
            "Sem. 12 (18 mar)",
            "Sem. 14 (1 abr)",
            estadisticas,
            "C:/MiProyecto/imagenes/grafica_uso.png",
            "C:/MiProyecto/output/reporte_paciente.pdf"
        );
    }
}
