package reportes;

import docbuilder.CDocBuilder;

public class main {
	 CDocBuilder.initialize("C:/Program Files/ONLYOFFICE/DocumentBuilder");
}
