package practica;

import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.property.*;

import java.io.IOException;

public class PdfService {

    public static void generarReporte(
            String rutaSalida,
            String nombrePaciente,
            String semanaInicio,
            String semanaFin,
            String[][] estadisticas,   // [["Métrica", "Valor"], ...]
            String rutaGrafica         // ruta local o URL de la imagen
    ) throws IOException {

        PdfWriter writer   = new PdfWriter(rutaSalida);
        PdfDocument pdf    = new PdfDocument(writer);
        Document document  = new Document(pdf, PageSize.A4);
        document.setMargins(36, 36, 36, 36);

        // ── 1. CABECERA ────────────────────────────────────────────────
        DeviceRgb azulOscuro = new DeviceRgb(0, 70, 127);

        // Tabla de cabecera: logo / título / rango de semanas
        Table header = new Table(UnitValue.createPercentArray(new float[]{1, 3, 1}))
                .useAllAvailableWidth();

        // Celda izquierda – espacio para logo (opcional)
        header.addCell(new Cell()
                .setBorder(Border.NO_BORDER)
                .add(new Paragraph("🏥").setFontSize(28)));

        // Celda central – nombre del paciente
        header.addCell(new Cell()
                .setBorder(Border.NO_BORDER)
                .setTextAlignment(TextAlignment.CENTER)
                .add(new Paragraph("Informe de Paciente")
                        .setBold().setFontSize(10)
                        .setFontColor(ColorConstants.GRAY))
                .add(new Paragraph(nombrePaciente)
                        .setBold().setFontSize(18)
                        .setFontColor(azulOscuro)));

        // Celda derecha – rango de semanas
        header.addCell(new Cell()
                .setBorder(Border.NO_BORDER)
                .setTextAlignment(TextAlignment.RIGHT)
                .add(new Paragraph("Período")
                        .setFontSize(9).setFontColor(ColorConstants.GRAY))
                .add(new Paragraph(semanaInicio + " – " + semanaFin)
                        .setBold().setFontSize(11)
                        .setFontColor(azulOscuro)));

        document.add(header);

        // Línea separadora
        document.add(new LineSeparator(new com.itextpdf.layout.element.TabStop())
                // forma más simple: un párrafo vacío con borde inferior
        );
        document.add(new Paragraph()
                .setBorderBottom(new com.itextpdf.layout.borders.SolidBorder(azulOscuro, 2))
                .setMarginBottom(12));

        // ── 2. TABLA DE ESTADÍSTICAS ───────────────────────────────────
        document.add(new Paragraph("Estadísticas del período")
                .setBold().setFontSize(13)
                .setFontColor(azulOscuro)
                .setMarginBottom(6));

        // Dos columnas: Métrica | Valor
        Table tabla = new Table(UnitValue.createPercentArray(new float[]{3, 2}))
                .useAllAvailableWidth()
                .setMarginBottom(20);

        // Encabezados
        DeviceRgb azulClaro = new DeviceRgb(220, 235, 250);
        for (String col : new String[]{"Métrica", "Valor"}) {
            tabla.addHeaderCell(new Cell()
                    .setBackgroundColor(azulOscuro)
                    .add(new Paragraph(col)
                            .setBold()
                            .setFontColor(ColorConstants.WHITE)
                            .setFontSize(11)));
        }

        // Filas de datos (color alterno)
        for (int i = 0; i < estadisticas.length; i++) {
            DeviceRgb fondo = (i % 2 == 0) ? azulClaro
                                            : new DeviceRgb(255, 255, 255);
            for (String celda : estadisticas[i]) {
                tabla.addCell(new Cell()
                        .setBackgroundColor(fondo)
                        .add(new Paragraph(celda).setFontSize(10)));
            }
        }

        document.add(tabla);

        // ── 3. IMAGEN DE LA GRÁFICA ────────────────────────────────────
        document.add(new Paragraph("Gráfica de uso")
                .setBold().setFontSize(13)
                .setFontColor(azulOscuro)
                .setMarginBottom(6));

        Image grafica = new Image(ImageDataFactory.create(rutaGrafica))
                .setWidth(UnitValue.createPercentValue(100))
                .setAutoScale(true)
                .setHorizontalAlignment(HorizontalAlignment.CENTER);

        document.add(grafica);

        // ── CIERRE ─────────────────────────────────────────────────────
        document.close();
        System.out.println("PDF generado en: " + rutaSalida);
    }

    // ── Ejemplo de uso ─────────────────────────────────────────────────
    public static void main(String[] args) throws IOException {
        String[][] stats = {
            {"Horas de uso diario (promedio)", "6.4 h"},
            {"Días activos",                   "18 / 21"},
            {"Sesiones completadas",           "54"},
            {"Adherencia al plan",             "86 %"},
            {"Alertas generadas",              "3"},
        };

        generarReporte(
            "reporte_paciente.pdf",
            "Ana García López",
            "Sem. 12 (18 mar)",
            "Sem. 14 (1 abr)",
            stats,
            "ruta/a/grafica_uso.png"   // PNG, JPG o URL https://...
        );
    }
}