package reportes;

import docbuilder.CDocBuilder;
import reportes.builder.DocBuilderScript;
import reportes.export.CSVExporter;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class GeneradorReporteConCSV {

    private static final String BUILDER_DIR =
            "C:/Program Files/ONLYOFFICE/DocumentBuilder";

    // ─────────────────────────────────────────────────────────────────────
    // EXPORTAR PDF  (OnlyOffice Document Builder)
    // ─────────────────────────────────────────────────────────────────────
    public static void exportarPDF(
            String nombrePaciente,
            String semanaInicio,
            String semanaFin,
            String[][] estadisticas,
            String rutaImagen,
            String rutaSalida
    ) throws Exception {

        String script = new DocBuilderScript()
                .colorPrimario(0, 70, 127)
                .fuentes(40, 20, 28, 20)
                .cabecera("INFORME DE PACIENTE", nombrePaciente, semanaInicio, semanaFin)
                .tablaEstadisticas("Estadísticas del período", estadisticas)
                .imagenGrafica("Gráfica de uso", rutaImagen, 15.0, 8.0)
                .build(rutaSalida);

        Path scriptTemp = Files.createTempFile("reporte_", ".docbuilder");
        Files.writeString(scriptTemp, script, StandardCharsets.UTF_8);

        CDocBuilder.initialize(BUILDER_DIR);
        CDocBuilder builder = new CDocBuilder();
        try {
            builder.run(scriptTemp.toString());
            System.out.println("✅ PDF generado en: " + rutaSalida);
        } finally {
            // Algunas versiones del JAR de DocumentBuilder no exponen un método
            // público `destroy()`; invocamos de forma segura mediante reflexión
            // (también intentamos `close()` por si sigue la convención AutoCloseable).
            if (builder != null) {
                try {
                    try {
                        java.lang.reflect.Method m = builder.getClass().getMethod("destroy");
                        m.invoke(builder);
                    } catch (NoSuchMethodException e1) {
                        try {
                            java.lang.reflect.Method m = builder.getClass().getDeclaredMethod("destroy");
                            m.setAccessible(true);
                            m.invoke(builder);
                        } catch (NoSuchMethodException e2) {
                            try {
                                java.lang.reflect.Method m = builder.getClass().getMethod("close");
                                m.invoke(builder);
                            } catch (NoSuchMethodException e3) {
                                System.err.println("Aviso: CDocBuilder no expone destroy/close públicamente.");
                            }
                        }
                    }
                } catch (Exception ex) {
                    System.err.println("Error al invocar destroy/close en CDocBuilder: " + ex);
                }
            }

            CDocBuilder.dispose();
            Files.deleteIfExists(scriptTemp);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // EXPORTAR CSV  (Java puro, sin OnlyOffice)
    // ─────────────────────────────────────────────────────────────────────
    public static void exportarCSV(
            String nombrePaciente,
            String semanaInicio,
            String semanaFin,
            String[][] estadisticas,
            String rutaSalida
    ) throws Exception {

        new CSVExporter()
                .separador(';')       // punto y coma: compatible con Excel en español
                .conBOM()             // tildes y ñ correctas en Excel
                .metadatos(nombrePaciente, semanaInicio, semanaFin)
                .estadisticas(estadisticas)
                .exportar(rutaSalida);
    }

    // ─────────────────────────────────────────────────────────────────────
    // EXPORTAR AMBOS A LA VEZ
    // ─────────────────────────────────────────────────────────────────────
    public static void exportarTodo(
            String nombrePaciente,
            String semanaInicio,
            String semanaFin,
            String[][] estadisticas,
            String rutaImagen,
            String carpetaSalida       // ej: "C:/output/"
    ) throws Exception {

        // Construir rutas con el nombre del paciente como prefijo
        String prefijo = carpetaSalida + nombrePaciente.replaceAll("\\s+", "_");

        exportarPDF(nombrePaciente, semanaInicio, semanaFin,
                estadisticas, rutaImagen, prefijo + ".pdf");

        exportarCSV(nombrePaciente, semanaInicio, semanaFin,
                estadisticas, prefijo + ".csv");
    }

    // ─────────────────────────────────────────────────────────────────────
    // EJEMPLO DE USO
    // ─────────────────────────────────────────────────────────────────────
    public static void main(String[] args) throws Exception {

        String[][] estadisticas = {
            {"Horas de uso diario (promedio)", "6.4 h"},
            {"Días activos",                   "18 / 21"},
            {"Sesiones completadas",           "54"},
            {"Adherencia al plan",             "86 %"},
            {"Alertas generadas",              "3"}
        };

        // Solo CSV
        exportarCSV(
            "Ana García López",
            "Sem. 12 (18 mar)",
            "Sem. 14 (1 abr)",
            estadisticas,
            "C:/MiProyecto/output/reporte_ana.csv"
        );

        // PDF + CSV en un solo paso
        exportarTodo(
            "Ana García López",
            "Sem. 12 (18 mar)",
            "Sem. 14 (1 abr)",
            estadisticas,
            "C:/MiProyecto/imagenes/grafica_uso.png",
            "C:/MiProyecto/output/"
            // genera: Ana_García_López.pdf  y  Ana_García_López.csv
        );
    }
}
