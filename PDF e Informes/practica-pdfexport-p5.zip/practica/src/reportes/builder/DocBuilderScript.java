package reportes.builder;

import java.util.ArrayList;
import java.util.List;

/**
 * Genera un script .docbuilder de forma programática usando un patrón fluido.
 *
 * Uso:
 *   String script = new DocBuilderScript()
 *       .titulo("Informe", "Ana García", "Sem. 12", "Sem. 14")
 *       .tablaEstadisticas(datos)
 *       .imagenGrafica("C:/img/grafica.png")
 *       .build("C:/output/reporte.pdf");
 */
public class DocBuilderScript {

    // ── Líneas del script acumuladas ──────────────────────────────────────
    private final List<String> lineas = new ArrayList<>();

    // ── Paleta de color activa ────────────────────────────────────────────
    private int[] colorPrimario = {0, 70, 127};      // azul corporativo
    private int[] colorSecundario = {220, 235, 250}; // azul claro (filas alternas)
    private int[] colorTextoOscuro = {50, 50, 50};
    private int[] colorBlanco = {255, 255, 255};
    private int[] colorGris = {150, 150, 150};

    // ── Tamaños de fuente (en half-points: 24 = 12pt) ────────────────────
    private int fuenteTitulo = 40;
    private int fuenteSubtitulo = 20;
    private int fuenteSeccion = 28;
    private int fuenteTabla = 20;

    // ─────────────────────────────────────────────────────────────────────
    // CONSTRUCTOR
    // ─────────────────────────────────────────────────────────────────────

    public DocBuilderScript() {
        // Encabezado obligatorio del script
        lineas.add("builder.CreateFile(\"pdf\");");
        lineas.add("builder.SetTmpFolder(\"DocBuilderTemp\");");
        lineas.add("var oDocument = Api.GetDocument();");
        lineas.add("");
        configurarPagina();
    }

    // ─────────────────────────────────────────────────────────────────────
    // API PÚBLICA — métodos encadenables
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Personaliza la paleta de colores.
     * @param r, g, b  Color primario (por defecto: azul 0,70,127)
     */
    public DocBuilderScript colorPrimario(int r, int g, int b) {
        this.colorPrimario = new int[]{r, g, b};
        return this;
    }

    /**
     * Personaliza el tamaño de las fuentes.
     */
    public DocBuilderScript fuentes(int titulo, int subtitulo, int seccion, int tabla) {
        this.fuenteTitulo    = titulo;
        this.fuenteSubtitulo = subtitulo;
        this.fuenteSeccion   = seccion;
        this.fuenteTabla     = tabla;
        return this;
    }

    /**
     * Cabecera del informe con nombre del paciente y período.
     *
     * @param etiqueta     Texto pequeño superior, ej: "INFORME DE PACIENTE"
     * @param nombre       Nombre del paciente
     * @param semanaInicio Ej: "Sem. 12 (18 mar)"
     * @param semanaFin    Ej: "Sem. 14 (1 abr)"
     */
    public DocBuilderScript cabecera(String etiqueta, String nombre,
                                     String semanaInicio, String semanaFin) {
        comentario("CABECERA");

        // Etiqueta superior
        nuevoParagrafo("oParEtiqueta");
        setJc("oParEtiqueta", "center");
        nuevoRun("oRunEtiqueta", js(etiqueta), fuenteSubtitulo,
                colorGris, false, true);
        pushRun("oParEtiqueta", "oRunEtiqueta");
        pushDoc("oParEtiqueta");

        // Nombre del paciente
        nuevoParagrafo("oParNombre");
        setJc("oParNombre", "center");
        nuevoRun("oRunNombre", js(nombre), fuenteTitulo,
                colorPrimario, true, false);
        pushRun("oParNombre", "oRunNombre");
        pushDoc("oParNombre");

        // Período de semanas
        nuevoParagrafo("oParPeriodo");
        setJc("oParPeriodo", "center");
        setSpacingAfter("oParPeriodo", 240);
        String periodo = js("Período: " + semanaInicio + "  –  " + semanaFin);
        nuevoRun("oRunPeriodo", periodo, fuenteSubtitulo + 2,
                colorPrimario, false, false);
        pushRun("oParPeriodo", "oRunPeriodo");
        pushDoc("oParPeriodo");

        // Separador: párrafo con fondo del color primario
        separador();

        return this;
    }

    /**
     * Agrega una tabla de dos columnas (Métrica | Valor).
     *
     * @param tituloSeccion Título visible sobre la tabla
     * @param filas         Array de pares {{"Métrica", "Valor"}, ...}
     */
    public DocBuilderScript tablaEstadisticas(String tituloSeccion, String[][] filas) {
        comentario("TABLA DE ESTADÍSTICAS");

        // Título de la sección
        tituloSeccion(tituloSeccion, "oParTitTabla");

        // Crear tabla
        int nFilas = filas.length + 1; // +1 encabezado
        linea("var oTabla = Api.CreateTable(2, " + nFilas + ");");
        linea("oTabla.SetWidth(\"percent\", 100);");
        bordesTabla("oTabla", 180, 200, 220);

        // Fila de encabezado
        linea("var oFilaEnc = oTabla.GetRow(0);");
        celdaEncabezado("oFilaEnc", 0, "Métrica", "left");
        celdaEncabezado("oFilaEnc", 1, "Valor", "center");

        // Filas de datos
        linea("var aStats = " + serializarArray(filas) + ";");
        linea("for (var _i = 0; _i < aStats.length; _i++) {");
        linea("  var _fila = oTabla.GetRow(_i + 1);");
        linea("  var _rBg = (_i % 2 === 0) ? " + colorSecundario[0] + " : 255;");
        linea("  var _gBg = (_i % 2 === 0) ? " + colorSecundario[1] + " : 255;");
        linea("  var _bBg = (_i % 2 === 0) ? " + colorSecundario[2] + " : 255;");
        // Celda Métrica
        linea("  var _cm = _fila.GetCell(0);");
        linea("  _cm.SetShd(\"clear\", _rBg, _gBg, _bBg);");
        linea("  var _pm = _cm.GetContent().GetElement(0);");
        linea("  var _rm = Api.CreateRun();");
        linea("  _rm.AddText(aStats[_i][0]);");
        linea("  _rm.SetFontSize(" + fuenteTabla + ");");
        linea("  _pm.AddElement(_rm);");
        // Celda Valor
        linea("  var _cv = _fila.GetCell(1);");
        linea("  _cv.SetShd(\"clear\", _rBg, _gBg, _bBg);");
        linea("  var _pv = _cv.GetContent().GetElement(0);");
        linea("  _pv.SetJc(\"center\");");
        linea("  var _rv = Api.CreateRun();");
        linea("  _rv.AddText(aStats[_i][1]);");
        linea("  _rv.SetFontSize(" + fuenteTabla + ");");
        linea("  _rv.SetBold(true);");
        color("_rv", colorPrimario);
        linea("  _pv.AddElement(_rv);");
        linea("}");

        pushDoc("oTabla");
        lineas.add("");
        return this;
    }

    /**
     * Agrega una imagen (gráfica) centrada en la página.
     *
     * @param tituloSeccion Título visible sobre la imagen
     * @param rutaImagen    Ruta absoluta al archivo PNG/JPG
     * @param anchoCm       Ancho deseado en centímetros
     * @param altoCm        Alto deseado en centímetros
     */
    public DocBuilderScript imagenGrafica(String tituloSeccion,
                                           String rutaImagen,
                                           double anchoCm, double altoCm) {
        comentario("IMAGEN DE LA GRÁFICA");
        tituloSeccion(tituloSeccion, "oParTitGrafica");

        // Convertir cm → EMU (1 cm = 360000 EMU)
        long anchoEmu = Math.round(anchoCm * 360000);
        long altoEmu  = Math.round(altoCm  * 360000);
        String url = "file:///" + rutaImagen.replace("\\", "/");

        linea("var oParImg = Api.CreateParagraph();");
        linea("oParImg.SetJc(\"center\");");
        linea("var oImagen = Api.CreateImage(\"" + url + "\", " + anchoEmu + ", " + altoEmu + ");");
        linea("oParImg.AddDrawing(oImagen);");
        pushDoc("oParImg");
        lineas.add("");
        return this;
    }

    /**
     * Agrega un párrafo de texto libre.
     *
     * @param texto     Contenido del párrafo
     * @param negrita   Si el texto es negrita
     * @param alineacion "left" | "center" | "right"
     */
    public DocBuilderScript parrafo(String texto, boolean negrita, String alineacion) {
        comentario("Párrafo");
        String pVar = "oPar_" + System.nanoTime();
        String rVar = "oRun_" + System.nanoTime();
        nuevoParagrafo(pVar);
        setJc(pVar, alineacion);
        nuevoRun(rVar, js(texto), fuenteTabla, colorTextoOscuro, negrita, false);
        pushRun(pVar, rVar);
        pushDoc(pVar);
        lineas.add("");
        return this;
    }

    /**
     * Agrega una línea en blanco como espaciado.
     */
    public DocBuilderScript espaciado() {
        linea("oDocument.Push(Api.CreateParagraph());");
        return this;
    }

    /**
     * Construye y devuelve el script completo como String.
     *
     * @param rutaSalidaPDF Ruta absoluta donde se guardará el PDF
     */
    public String build(String rutaSalidaPDF) {
        comentario("GUARDAR");
        linea("builder.SaveFile(\"pdf\", \"" + rutaSalidaPDF.replace("\\", "/") + "\");");
        linea("builder.CloseFile();");
        return String.join("\n", lineas);
    }

    // ─────────────────────────────────────────────────────────────────────
    // MÉTODOS PRIVADOS DE CONSTRUCCIÓN
    // ─────────────────────────────────────────────────────────────────────

    private void configurarPagina() {
        comentario("Configuración de página A4");
        linea("var oSection = oDocument.GetFinalSection();");
        linea("oSection.SetPageSize(12240, 15840);");
        linea("oSection.SetPageMargins(1080, 720, 1080, 720);");
        lineas.add("");
    }

    private void nuevoParagrafo(String varName) {
        linea("var " + varName + " = Api.CreateParagraph();");
    }

    private void nuevoRun(String varName, String texto, int fontSize,
                          int[] color, boolean bold, boolean italic) {
        linea("var " + varName + " = Api.CreateRun();");
        linea(varName + ".AddText(" + texto + ");");
        linea(varName + ".SetFontSize(" + fontSize + ");");
        color(varName, color);
        if (bold)   linea(varName + ".SetBold(true);");
        if (italic) linea(varName + ".SetItalic(true);");
    }

    private void pushRun(String parVar, String runVar) {
        linea(parVar + ".AddElement(" + runVar + ");");
    }

    private void pushDoc(String var) {
        linea("oDocument.Push(" + var + ");");
    }

    private void setJc(String var, String align) {
        linea(var + ".SetJc(\"" + align + "\");");
    }

    private void setSpacingAfter(String var, int twips) {
        linea(var + ".SetSpacingAfter(" + twips + ");");
    }

    private void color(String var, int[] rgb) {
        linea(var + ".SetColor(" + rgb[0] + ", " + rgb[1] + ", " + rgb[2] + ");");
    }

    private void separador() {
        linea("var oSep = Api.CreateParagraph();");
        linea("oSep.SetParagraphShd(\"clear\", " +
              colorPrimario[0] + ", " + colorPrimario[1] + ", " + colorPrimario[2] + ");");
        linea("oSep.SetSpacingAfter(240);");
        pushDoc("oSep");
        lineas.add("");
    }

    private void tituloSeccion(String titulo, String varName) {
        nuevoParagrafo(varName);
        linea(varName + ".SetSpacingBefore(240);");
        linea(varName + ".SetSpacingAfter(120);");
        String rVar = varName + "Run";
        nuevoRun(rVar, js(titulo), fuenteSeccion, colorPrimario, true, false);
        pushRun(varName, rVar);
        pushDoc(varName);
    }

    private void celdaEncabezado(String filaVar, int col, String texto, String align) {
        String cVar = "oEncC" + col;
        String pVar = "oEncP" + col;
        String rVar = "oEncR" + col;
        linea("var " + cVar + " = " + filaVar + ".GetCell(" + col + ");");
        linea(cVar + ".SetShd(\"clear\", " +
              colorPrimario[0] + ", " + colorPrimario[1] + ", " + colorPrimario[2] + ");");
        linea("var " + pVar + " = " + cVar + ".GetContent().GetElement(0);");
        if (!align.equals("left")) linea(pVar + ".SetJc(\"" + align + "\");");
        linea("var " + rVar + " = Api.CreateRun();");
        linea(rVar + ".AddText(\"" + escaparJS(texto) + "\");");
        linea(rVar + ".SetBold(true);");
        linea(rVar + ".SetFontSize(" + (fuenteTabla + 2) + ");");
        linea(rVar + ".SetColor(255, 255, 255);");
        linea(pVar + ".AddElement(" + rVar + ");");
    }

    private void bordesTabla(String var, int r, int g, int b) {
        for (String lado : List.of("Top", "Bottom", "Left", "Right", "InsideH", "InsideV")) {
            linea(var + ".SetTableBorder" + lado + "(\"single\", 4, 0, " + r + ", " + g + ", " + b + ");");
        }
    }

    private void comentario(String texto) {
        lineas.add("// ── " + texto + " " + "─".repeat(Math.max(0, 60 - texto.length())));
    }

    private void linea(String codigo) {
        lineas.add(codigo);
    }

    /** Escapa un String para usarlo como literal JS */
    private static String js(String s) {
        return "\"" + escaparJS(s) + "\"";
    }

    private static String escaparJS(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n");
    }

    /** Serializa String[][] como array literal JS */
    private static String serializarArray(String[][] datos) {
        StringBuilder sb = new StringBuilder("[\n");
        for (int i = 0; i < datos.length; i++) {
            sb.append("  [\"").append(escaparJS(datos[i][0]))
              .append("\", \"").append(escaparJS(datos[i][1])).append("\"]");
            if (i < datos.length - 1) sb.append(",");
            sb.append("\n");
        }
        return sb.append("]").toString();
    }
}
