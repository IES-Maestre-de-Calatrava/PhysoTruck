package reportes;

import docbuilder.CDocBuilder;
import reportes.builder.DocBuilderScript;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.lang.reflect.Method;

public class GeneradorReporte {

    private static final String BUILDER_DIR =
            "C:/Program Files/ONLYOFFICE/DocumentBuilder";

    /**
     * Genera un PDF de reporte de paciente usando DocBuilderScript.
     */
    public static void generarPDF(
            String nombrePaciente,
            String semanaInicio,
            String semanaFin,
            String[][] estadisticas,
            String rutaImagen,
            String rutaSalida
    ) throws Exception {

        // 1. Construir el script con la clase fluida
        String script = new DocBuilderScript()
                .colorPrimario(0, 70, 127)               // azul corporativo
                .fuentes(40, 20, 28, 20)                 // título / sub / sección / tabla
                .cabecera(
                    "INFORME DE PACIENTE",
                    nombrePaciente,
                    semanaInicio,
                    semanaFin
                )
                .tablaEstadisticas("Estadísticas del período", estadisticas)
                .imagenGrafica("Gráfica de uso", rutaImagen, 15.0, 8.0)
                .build(rutaSalida);

        // 2. Guardar el script en un archivo temporal
        Path scriptTemp = Files.createTempFile("reporte_", ".docbuilder");
        Files.writeString(scriptTemp, script, StandardCharsets.UTF_8);
        System.out.println("Script generado:\n" + script); // útil para depurar

        // 3. Ejecutar con CDocBuilder
        CDocBuilder.initialize(BUILDER_DIR);
        CDocBuilder builder = new CDocBuilder();
        try {
            builder.run(scriptTemp.toString());
            System.out.println("✅ PDF generado en: " + rutaSalida);
        } finally {
            // Intentamos cerrar/terminar el builder de forma segura.
            // No hacemos cast a Object (eso no aporta métodos) sino que intentamos llamar
            // a destroy/close mediante reflexión si el método no es visible en tiempo de compilación.
            try {
                // 1) método público destroy()
                try {
                    Method m = builder.getClass().getMethod("destroy");
                    m.invoke(builder);
                } catch (NoSuchMethodException e1) {
                    // 2) método no público destroy()
                    try {
                        Method m = builder.getClass().getDeclaredMethod("destroy");
                        m.setAccessible(true);
                        m.invoke(builder);
                    } catch (NoSuchMethodException e2) {
                        // 3) intentar close() (convención AutoCloseable)
                        try {
                            Method m = builder.getClass().getMethod("close");
                            m.invoke(builder);
                        } catch (NoSuchMethodException e3) {
                            // No hay método conocido para cerrar; nada que hacer
                            System.err.println("Aviso: CDocBuilder no expone destroy/close públicamente.");
                        }
                    }
                }
            } catch (Exception ex) {
                // No detener la limpieza si falla la invocación por reflexión
                System.err.println("Error al invocar destroy/close en CDocBuilder: " + ex);
            }

            // Llamada estática de limpieza si la librería la requiere
            CDocBuilder.dispose();
            Files.deleteIfExists(scriptTemp);
        }
    }

    // ── Ejemplo de uso ─────────────────────────────────────────────────────
    public static void main(String[] args) throws Exception {

        String[][] estadisticas = {
            {"Horas de uso diario (promedio)", "6.4 h"},
            {"Días activos",                   "18 / 21"},
            {"Sesiones completadas",           "54"},
            {"Adherencia al plan",             "86 %"},
            {"Alertas generadas",              "3"}
        };

        generarPDF(
            "Ana García López",
            "Sem. 12 (18 mar)",
            "Sem. 14 (1 abr)",
            estadisticas,
            "C:/MiProyecto/imagenes/grafica_uso.png",
            "C:/MiProyecto/output/reporte_paciente.pdf"
        );
    }
}
