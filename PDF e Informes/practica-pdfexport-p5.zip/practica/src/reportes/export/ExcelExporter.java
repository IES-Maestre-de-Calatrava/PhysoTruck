package reportes.export;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Exporta los datos del reporte de paciente a un archivo Excel (.xlsx).
 * Usa Apache POI — agregar al pom.xml:
 *
 *   <dependency>
 *     <groupId>org.apache.poi</groupId>
 *     <artifactId>poi-ooxml</artifactId>
 *     <version>5.2.5</version>
 *   </dependency>
 *
 * Uso:
 *   new ExcelExporter()
 *       .metadatos("Ana García", "Sem. 12", "Sem. 14")
 *       .estadisticas(datos)
 *       .exportar("C:/output/reporte.xlsx");
 */
public class ExcelExporter {

    // ── Libro de trabajo ──────────────────────────────────────────────────
    private final XSSFWorkbook wb = new XSSFWorkbook();
    private final XSSFSheet hoja;

    // ── Estilos reutilizables ─────────────────────────────────────────────
    private final CellStyle estTitulo;
    private final CellStyle estSeccion;
    private final CellStyle estEncabezado;
    private final CellStyle estDatoClaro;
    private final CellStyle estDatoOscuro;
    private final CellStyle estValorClaro;
    private final CellStyle estValorOscuro;
    private final CellStyle estMeta;

    // ── Fila actual ───────────────────────────────────────────────────────
    private int filaActual = 0;

    // ── Paleta de color ───────────────────────────────────────────────────
    private static final String AZUL_OSC  = "00467F";  // encabezados
    private static final String AZUL_MED  = "1A6FAF";  // secciones
    private static final String AZUL_CL   = "DCEBFA";  // filas alternas
    private static final String BLANCO    = "FFFFFF";
    private static final String GRIS_CL   = "F5F5F5";  // metadatos

    // ─────────────────────────────────────────────────────────────────────
    // CONSTRUCTOR
    // ─────────────────────────────────────────────────────────────────────

    public ExcelExporter() {
        hoja = wb.createSheet("Reporte");
        hoja.setDefaultColumnWidth(20);
        hoja.setColumnWidth(0, 40 * 256);  // col A más ancha (métricas)
        hoja.setColumnWidth(1, 20 * 256);  // col B (valores)

        // Crear todos los estilos una sola vez (POI tiene límite de estilos)
        estTitulo     = crearEstilo(AZUL_OSC, BLANCO,  16, true,  false);
        estSeccion    = crearEstilo(AZUL_MED, BLANCO,  11, true,  false);
        estEncabezado = crearEstilo(AZUL_OSC, BLANCO,  10, true,  false);
        estDatoClaro  = crearEstilo(BLANCO,   "2C2C2A", 10, false, false);
        estDatoOscuro = crearEstilo(AZUL_CL,  "2C2C2A", 10, false, false);
        estValorClaro = crearEstilo(BLANCO,   AZUL_OSC, 10, true,  false);
        estValorOscuro= crearEstilo(AZUL_CL,  AZUL_OSC, 10, true,  false);
        estMeta       = crearEstilo(GRIS_CL,  "5F5E5A", 10, false, true);
    }

    // ─────────────────────────────────────────────────────────────────────
    // API PÚBLICA — métodos encadenables
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Cabecera principal: título grande + datos del paciente y período.
     */
    public ExcelExporter metadatos(String nombrePaciente,
                                    String semanaInicio,
                                    String semanaFin) {
        // Fila de título (fusionada A–B)
        agregarFilaTitulo("INFORME DE PACIENTE", estTitulo);

        // Línea en blanco
        filaActual++;

        // Datos del paciente
        agregarFilaMeta("Paciente",      nombrePaciente);
        agregarFilaMeta("Semana inicio", semanaInicio);
        agregarFilaMeta("Semana fin",    semanaFin);
        agregarFilaMeta("Exportado el",
                LocalDateTime.now().format(
                        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));

        // Línea en blanco separadora
        filaActual++;
        return this;
    }

    /**
     * Tabla de dos columnas (Métrica | Valor) con filas alternas.
     *
     * @param titulo Título visible sobre la tabla
     * @param datos  Array de pares {{"Métrica", "Valor"}, ...}
     */
    public ExcelExporter estadisticas(String titulo, String[][] datos) {
        // Encabezado de sección
        agregarFilaTitulo(titulo, estSeccion);

        // Encabezados de columna
        Row enc = hoja.createRow(filaActual++);
        enc.setHeightInPoints(22);
        celda(enc, 0, "Métrica", estEncabezado);
        celda(enc, 1, "Valor",   estEncabezado);

        // Filas de datos
        for (int i = 0; i < datos.length; i++) {
            boolean par = i % 2 == 0;
            Row fila = hoja.createRow(filaActual++);
            fila.setHeightInPoints(18);
            celda(fila, 0, datos[i][0], par ? estDatoOscuro  : estDatoClaro);
            celda(fila, 1, datos[i][1], par ? estValorOscuro : estValorClaro);
        }

        // Línea en blanco
        filaActual++;
        return this;
    }

    /**
     * Sección genérica con título, encabezados de columna y filas de datos.
     *
     * @param titulo      Título de la sección
     * @param encabezados Nombres de columnas (cualquier cantidad)
     * @param datos       Filas de datos
     */
    public ExcelExporter seccion(String titulo,
                                  String[] encabezados,
                                  String[][] datos) {
        agregarFilaTitulo(titulo, estSeccion);

        // Encabezados dinámicos
        Row enc = hoja.createRow(filaActual++);
        enc.setHeightInPoints(22);
        for (int c = 0; c < encabezados.length; c++) {
            celda(enc, c, encabezados[c], estEncabezado);
            // Ajustar ancho de columnas extras automáticamente
            if (c >= 2) hoja.setColumnWidth(c, 18 * 256);
        }

        // Filas de datos
        for (int i = 0; i < datos.length; i++) {
            boolean par = i % 2 == 0;
            Row fila = hoja.createRow(filaActual++);
            fila.setHeightInPoints(18);
            for (int c = 0; c < datos[i].length; c++) {
                CellStyle estilo = (c == 0)
                        ? (par ? estDatoOscuro  : estDatoClaro)
                        : (par ? estValorOscuro : estValorClaro);
                celda(fila, c, datos[i][c], estilo);
            }
        }

        filaActual++;
        return this;
    }

    /**
     * Agrega una fila de nota al pie (texto en gris claro).
     */
    public ExcelExporter nota(String texto) {
        Row fila = hoja.createRow(filaActual++);
        celda(fila, 0, "* " + texto, estMeta);
        hoja.addMergedRegion(new CellRangeAddress(
                filaActual - 1, filaActual - 1, 0, 1));
        return this;
    }

    /**
     * Agrega una línea en blanco como separador visual.
     */
    public ExcelExporter lineaEnBlanco() {
        filaActual++;
        return this;
    }

    /**
     * Escribe el archivo .xlsx en la ruta indicada.
     *
     * @param rutaSalida Ruta absoluta del archivo de salida
     * @throws IOException Si no puede escribir el archivo
     */
    public void exportar(String rutaSalida) throws IOException {
        Path path = Path.of(rutaSalida);
        Files.createDirectories(path.getParent());

        try (var os = Files.newOutputStream(path)) {
            wb.write(os);
        }

        wb.close();
        System.out.println("✅ Excel generado en: " + rutaSalida);
    }

    // ─────────────────────────────────────────────────────────────────────
    // MÉTODOS PRIVADOS DE CONSTRUCCIÓN
    // ─────────────────────────────────────────────────────────────────────

    /** Crea una fila fusionada A–B con el texto dado y el estilo indicado. */
    private void agregarFilaTitulo(String texto, CellStyle estilo) {
        Row fila = hoja.createRow(filaActual);
        fila.setHeightInPoints(26);
        celda(fila, 0, texto, estilo);
        hoja.addMergedRegion(new CellRangeAddress(
                filaActual, filaActual, 0, 1));
        filaActual++;
    }

    /** Crea una fila de metadato: etiqueta (gris) | valor (gris). */
    private void agregarFilaMeta(String etiqueta, String valor) {
        Row fila = hoja.createRow(filaActual++);
        fila.setHeightInPoints(16);
        celda(fila, 0, etiqueta, estMeta);
        celda(fila, 1, valor,    estMeta);
    }

    /** Crea una celda con texto y estilo. */
    private void celda(Row fila, int col, String texto, CellStyle estilo) {
        Cell c = fila.createCell(col);
        c.setCellValue(texto != null ? texto : "");
        c.setCellStyle(estilo);
    }

    /**
     * Crea un CellStyle completo reutilizable.
     *
     * @param bgHex     Color de fondo en hex (sin #)
     * @param fgHex     Color de texto en hex (sin #)
     * @param fontSize  Tamaño de fuente en puntos
     * @param bold      Negrita
     * @param italic    Cursiva
     */
    private CellStyle crearEstilo(String bgHex, String fgHex,
                                   int fontSize, boolean bold, boolean italic) {
        XSSFCellStyle estilo = wb.createCellStyle();

        // Fondo
        estilo.setFillForegroundColor(new XSSFColor(hexToRgb(bgHex), null));
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        // Fuente
        XSSFFont fuente = wb.createFont();
        fuente.setFontName("Arial");
        fuente.setFontHeightInPoints((short) fontSize);
        fuente.setBold(bold);
        fuente.setItalic(italic);
        fuente.setColor(new XSSFColor(hexToRgb(fgHex), null));
        estilo.setFont(fuente);

        // Alineación y relleno interior
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        estilo.setAlignment(HorizontalAlignment.LEFT);
        estilo.setWrapText(false);

        // Borde inferior sutil
        estilo.setBorderBottom(BorderStyle.THIN);
        estilo.setBottomBorderColor(
                new XSSFColor(hexToRgb("D0D0D0"), null).getIndex());

        return estilo;
    }

    /** Convierte un color HEX a byte[] RGB. */
    private static byte[] hexToRgb(String hex) {
        return new byte[]{
            (byte) Integer.parseInt(hex.substring(0, 2), 16),
            (byte) Integer.parseInt(hex.substring(2, 4), 16),
            (byte) Integer.parseInt(hex.substring(4, 6), 16)
        };
    }
}
