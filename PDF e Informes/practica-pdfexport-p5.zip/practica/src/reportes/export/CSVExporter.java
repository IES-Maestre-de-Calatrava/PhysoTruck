package reportes.export;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Exporta los datos del reporte de paciente a un archivo CSV.
 *
 * Uso básico:
 *   new CSVExporter()
 *       .separador(';')               // opcional, defecto: ','
 *       .conBOM()                     // opcional, para Excel en español
 *       .metadatos("Ana García", "Sem. 12", "Sem. 14")
 *       .estadisticas(datos)
 *       .exportar("C:/output/reporte.csv");
 */
public class CSVExporter {

    // ── Configuración ─────────────────────────────────────────────────────
    private char separador    = ',';
    private boolean conBOM    = false;   // BOM hace que Excel lo abra bien en español
    private boolean conFechaExportacion = true;

    // ── Secciones acumuladas ──────────────────────────────────────────────
    private final List<String[]> filas = new ArrayList<>();

    // ─────────────────────────────────────────────────────────────────────
    // CONFIGURACIÓN
    // ─────────────────────────────────────────────────────────────────────

    /** Cambia el separador de columnas (defecto: coma). */
    public CSVExporter separador(char separador) {
        this.separador = separador;
        return this;
    }

    /**
     * Añade BOM UTF-8 al inicio del archivo.
     * Necesario para que Excel en Windows/español reconozca tildes y ñ.
     */
    public CSVExporter conBOM() {
        this.conBOM = true;
        return this;
    }

    /** Omite la línea de fecha de exportación. */
    public CSVExporter sinFechaExportacion() {
        this.conFechaExportacion = false;
        return this;
    }

    // ─────────────────────────────────────────────────────────────────────
    // SECCIONES DE CONTENIDO
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Agrega una sección de metadatos del paciente al inicio del CSV.
     *
     * @param nombrePaciente  Nombre completo
     * @param semanaInicio    Ej: "Sem. 12 (18 mar)"
     * @param semanaFin       Ej: "Sem. 14 (1 abr)"
     */
    public CSVExporter metadatos(String nombrePaciente,
                                  String semanaInicio,
                                  String semanaFin) {
        filas.add(new String[]{"INFORME DE PACIENTE"});
        filas.add(new String[]{"Paciente", nombrePaciente});
        filas.add(new String[]{"Semana inicio", semanaInicio});
        filas.add(new String[]{"Semana fin", semanaFin});

        if (conFechaExportacion) {
            String fecha = LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
            filas.add(new String[]{"Exportado el", fecha});
        }

        filas.add(new String[]{});  // línea en blanco separadora
        return this;
    }

    /**
     * Agrega la tabla de estadísticas con encabezados.
     *
     * @param datos Array de pares {{"Métrica", "Valor"}, ...}
     */
    public CSVExporter estadisticas(String[][] datos) {
        filas.add(new String[]{"ESTADÍSTICAS DEL PERÍODO"});
        filas.add(new String[]{"Métrica", "Valor"});   // encabezado de columnas

        for (String[] fila : datos) {
            filas.add(fila);
        }

        filas.add(new String[]{});  // línea en blanco separadora
        return this;
    }

    /**
     * Agrega una sección personalizada con su propio título y encabezados.
     *
     * @param titulo     Título de la sección
     * @param encabezados Nombres de las columnas
     * @param datos      Filas de datos
     */
    public CSVExporter seccion(String titulo,
                                String[] encabezados,
                                String[][] datos) {
        filas.add(new String[]{titulo});
        filas.add(encabezados);

        for (String[] fila : datos) {
            filas.add(fila);
        }

        filas.add(new String[]{});
        return this;
    }

    /**
     * Agrega una fila individual (útil para totales o notas al pie).
     */
    public CSVExporter fila(String... celdas) {
        filas.add(celdas);
        return this;
    }

    /**
     * Agrega una línea en blanco como separador visual.
     */
    public CSVExporter lineaEnBlanco() {
        filas.add(new String[]{});
        return this;
    }

    // ─────────────────────────────────────────────────────────────────────
    // EXPORTACIÓN
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Escribe el archivo CSV en la ruta indicada.
     *
     * @param rutaSalida Ruta absoluta del archivo de salida (ej: "C:/output/reporte.csv")
     * @throws IOException Si no puede escribir el archivo
     */
    public void exportar(String rutaSalida) throws IOException {
        Path path = Path.of(rutaSalida);

        // Crear directorios intermedios si no existen
        Files.createDirectories(path.getParent());

        try (OutputStream os = Files.newOutputStream(path);
             Writer writer = new OutputStreamWriter(os, StandardCharsets.UTF_8)) {

            // BOM para compatibilidad con Excel en español
            if (conBOM) {
                os.write(new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF});
            }

            for (String[] fila : filas) {
                writer.write(filaACSV(fila));
                writer.write(System.lineSeparator());
            }
        }

        System.out.println("✅ CSV exportado en: " + rutaSalida);
    }

    /**
     * Devuelve el contenido CSV como String (útil para tests o para enviarlo
     * como respuesta HTTP sin escribir en disco).
     */
    public String comoTexto() throws IOException {
        StringBuilder sb = new StringBuilder();
        for (String[] fila : filas) {
            sb.append(filaACSV(fila)).append(System.lineSeparator());
        }
        return sb.toString();
    }

    // ─────────────────────────────────────────────────────────────────────
    // UTILIDADES PRIVADAS
    // ─────────────────────────────────────────────────────────────────────

    /** Convierte un array de celdas a una línea CSV correctamente escapada. */
    private String filaACSV(String[] celdas) {
        if (celdas == null || celdas.length == 0) return "";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < celdas.length; i++) {
            if (i > 0) sb.append(separador);
            sb.append(escaparCelda(celdas[i]));
        }
        return sb.toString();
    }

    /**
     * Escapa una celda según RFC 4180:
     * - Si contiene separador, comillas o saltos de línea → envuelve en comillas dobles
     * - Las comillas internas se duplican ("")
     */
    private String escaparCelda(String valor) {
        if (valor == null) return "";

        boolean necesitaComillas = valor.contains(String.valueOf(separador))
                || valor.contains("\"")
                || valor.contains("\n")
                || valor.contains("\r");

        if (!necesitaComillas) return valor;

        return "\"" + valor.replace("\"", "\"\"") + "\"";
    }
}
