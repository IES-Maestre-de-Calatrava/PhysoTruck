package reportes;

/**
 * Genera el contenido del script .docbuilder con los datos reales del paciente.
 */
public class ScriptBuilder {

    /**
     * @param nombrePaciente  Nombre completo del paciente
     * @param semanaInicio    Ej: "Sem. 12 (18 mar)"
     * @param semanaFin       Ej: "Sem. 14 (1 abr)"
     * @param estadisticas    Filas de la tabla: {{"Métrica", "Valor"}, ...}
     * @param rutaImagen      Ruta absoluta de la imagen PNG/JPG de la gráfica
     * @param rutaSalida      Ruta absoluta donde se guardará el PDF
     */
    public static String generar(
            String nombrePaciente,
            String semanaInicio,
            String semanaFin,
            String[][] estadisticas,
            String rutaImagen,
            String rutaSalida
    ) {
        // Normalizar rutas (barras invertidas → slash para la API de OnlyOffice)
        String imgUrl   = "file:///" + rutaImagen.replace("\\", "/");
        String pdfPath  = rutaSalida.replace("\\", "/");

        // Serializar estadísticas como array JS
        StringBuilder jsArray = new StringBuilder("[\n");
        for (int i = 0; i < estadisticas.length; i++) {
            jsArray.append("  [\"")
                   .append(escaparJS(estadisticas[i][0])).append("\", \"")
                   .append(escaparJS(estadisticas[i][1])).append("\"]");
            if (i < estadisticas.length - 1) jsArray.append(",");
            jsArray.append("\n");
        }
        jsArray.append("]");

        return """
builder.CreateFile("pdf");
builder.SetTmpFolder("DocBuilderTemp");

var oDocument = Api.GetDocument();

// ─── Configuración de página ───────────────────────────────────────────────
var oSection = oDocument.GetFinalSection();
oSection.SetPageSize(12240, 15840);           // A4
oSection.SetPageMargins(1080, 720, 1080, 720); // márgenes: arriba/der/abajo/izq

// ─── Colores ───────────────────────────────────────────────────────────────
// Azul corporativo: RGB(0, 70, 127)
// Azul claro:       RGB(220, 235, 250)

// ═══════════════════════════════════════════════════════════════════════════
// 1. CABECERA
// ═══════════════════════════════════════════════════════════════════════════

// Subtítulo "INFORME DE PACIENTE"
var oParSub = Api.CreateParagraph();
oParSub.SetJc("center");
var oRunSub = Api.CreateRun();
oRunSub.AddText("INFORME DE PACIENTE");
oRunSub.SetFontSize(20);
oRunSub.SetColor(150, 150, 150);
oRunSub.SetItalic(true);
oParSub.AddElement(oRunSub);
oDocument.Push(oParSub);

// Nombre del paciente
var oParNombre = Api.CreateParagraph();
oParNombre.SetJc("center");
var oRunNombre = Api.CreateRun();
oRunNombre.AddText("%s");
oRunNombre.SetFontSize(40);
oRunNombre.SetBold(true);
oRunNombre.SetColor(0, 70, 127);
oParNombre.AddElement(oRunNombre);
oDocument.Push(oParNombre);

// Período (semanas)
var oParPeriodo = Api.CreateParagraph();
oParPeriodo.SetJc("center");
oParPeriodo.SetSpacingAfter(240);
var oRunPeriodo = Api.CreateRun();
oRunPeriodo.AddText("Período: %s  –  %s");
oRunPeriodo.SetFontSize(22);
oRunPeriodo.SetColor(0, 70, 127);
oParPeriodo.AddElement(oRunPeriodo);
oDocument.Push(oParPeriodo);

// Línea separadora (párrafo con fondo azul, altura mínima)
var oSep = Api.CreateParagraph();
oSep.SetParagraphShd("clear", 0, 70, 127);
oSep.SetSpacingAfter(240);
oDocument.Push(oSep);

// ═══════════════════════════════════════════════════════════════════════════
// 2. TABLA DE ESTADÍSTICAS
// ═══════════════════════════════════════════════════════════════════════════

var oParTitTabla = Api.CreateParagraph();
oParTitTabla.SetSpacingBefore(120);
oParTitTabla.SetSpacingAfter(120);
var oRunTitTabla = Api.CreateRun();
oRunTitTabla.AddText("Estadísticas del período");
oRunTitTabla.SetBold(true);
oRunTitTabla.SetFontSize(28);
oRunTitTabla.SetColor(0, 70, 127);
oParTitTabla.AddElement(oRunTitTabla);
oDocument.Push(oParTitTabla);

var aStats = %s;
var nFilas = aStats.length + 1;  // +1 para encabezado

var oTabla = Api.CreateTable(2, nFilas);
oTabla.SetWidth("percent", 100);
oTabla.SetTableBorderTop("single", 4, 0, 180, 200, 220);
oTabla.SetTableBorderBottom("single", 4, 0, 180, 200, 220);
oTabla.SetTableBorderLeft("single", 4, 0, 180, 200, 220);
oTabla.SetTableBorderRight("single", 4, 0, 180, 200, 220);
oTabla.SetTableBorderInsideH("single", 4, 0, 180, 200, 220);
oTabla.SetTableBorderInsideV("single", 4, 0, 180, 200, 220);

// — Fila de encabezado
var oFilaEnc = oTabla.GetRow(0);

var oCeldaEncMetrica = oFilaEnc.GetCell(0);
oCeldaEncMetrica.SetShd("clear", 0, 70, 127);
var oParEncMetrica = oCeldaEncMetrica.GetContent().GetElement(0);
var oRunEncMetrica = Api.CreateRun();
oRunEncMetrica.AddText("Métrica");
oRunEncMetrica.SetBold(true);
oRunEncMetrica.SetFontSize(22);
oRunEncMetrica.SetColor(255, 255, 255);
oParEncMetrica.AddElement(oRunEncMetrica);

var oCeldaEncValor = oFilaEnc.GetCell(1);
oCeldaEncValor.SetShd("clear", 0, 70, 127);
var oParEncValor = oCeldaEncValor.GetContent().GetElement(0);
oParEncValor.SetJc("center");
var oRunEncValor = Api.CreateRun();
oRunEncValor.AddText("Valor");
oRunEncValor.SetBold(true);
oRunEncValor.SetFontSize(22);
oRunEncValor.SetColor(255, 255, 255);
oParEncValor.AddElement(oRunEncValor);

// — Filas de datos
for (var i = 0; i < aStats.length; i++) {
  var oFila = oTabla.GetRow(i + 1);

  // Color alterno de fondo
  var rBg = (i % 2 === 0) ? 220 : 255;
  var gBg = (i % 2 === 0) ? 235 : 255;
  var bBg = (i % 2 === 0) ? 250 : 255;

  var oCeldaM = oFila.GetCell(0);
  oCeldaM.SetShd("clear", rBg, gBg, bBg);
  var oParM = oCeldaM.GetContent().GetElement(0);
  var oRunM = Api.CreateRun();
  oRunM.AddText(aStats[i][0]);
  oRunM.SetFontSize(20);
  oParM.AddElement(oRunM);

  var oCeldaV = oFila.GetCell(1);
  oCeldaV.SetShd("clear", rBg, gBg, bBg);
  var oParV = oCeldaV.GetContent().GetElement(0);
  oParV.SetJc("center");
  var oRunV = Api.CreateRun();
  oRunV.AddText(aStats[i][1]);
  oRunV.SetFontSize(20);
  oRunV.SetBold(true);
  oRunV.SetColor(0, 70, 127);
  oParV.AddElement(oRunV);
}

oDocument.Push(oTabla);

// ═══════════════════════════════════════════════════════════════════════════
// 3. IMAGEN DE LA GRÁFICA
// ═══════════════════════════════════════════════════════════════════════════

var oParTitGrafica = Api.CreateParagraph();
oParTitGrafica.SetSpacingBefore(360);
oParTitGrafica.SetSpacingAfter(120);
var oRunTitGrafica = Api.CreateRun();
oRunTitGrafica.AddText("Gráfica de uso");
oRunTitGrafica.SetBold(true);
oRunTitGrafica.SetFontSize(28);
oRunTitGrafica.SetColor(0, 70, 127);
oParTitGrafica.AddElement(oRunTitGrafica);
oDocument.Push(oParTitGrafica);

// Imagen: 15 cm × 8 cm  (1 cm = 360000 EMU)
var oParImg = Api.CreateParagraph();
oParImg.SetJc("center");
var oImagen = Api.CreateImage("%s", 5400000, 2880000);
oParImg.AddDrawing(oImagen);
oDocument.Push(oParImg);

// ─── Guardar ───────────────────────────────────────────────────────────────
builder.SaveFile("pdf", "%s");
builder.CloseFile();
""".formatted(
                nombrePaciente,
                semanaInicio, semanaFin,
                jsArray.toString(),
                imgUrl,
                pdfPath
        );
    }

    /** Escapa caracteres especiales para strings JavaScript */
    private static String escaparJS(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n");
    }
}