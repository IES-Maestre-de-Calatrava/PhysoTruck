/**
 * 
 */
/**
 * 
 */
module practica {
	requires docbuilder;
}