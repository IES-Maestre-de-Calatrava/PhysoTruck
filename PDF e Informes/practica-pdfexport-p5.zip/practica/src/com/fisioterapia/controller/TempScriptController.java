package com.fisioterapia.controller;

import com.fisioterapia.service.onlyoffice.TempScriptRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Endpoint auxiliar que expone los scripts JS temporales por HTTP
 * para que el OnlyOffice Document Server pueda descargarlos durante
 * la estrategia REST.
 *
 * <p>La URL típica es:
 * <pre>GET /api/fisio/temp-script/{fileName}</pre>
 *
 * <p>Sólo es necesario en la estrategia REST. Los scripts se eliminan
 * del registro en memoria al finalizar el job o tras 5 minutos como máximo.
 */
@RestController
@RequestMapping("/api/fisio/temp-script")
@Slf4j
public class TempScriptController {

    @GetMapping(value = "/{fileName}", produces = "application/javascript")
    public ResponseEntity<String> getScript(@PathVariable String fileName) {

        // Seguridad básica: evitar path traversal
        if (fileName.contains("..") || fileName.contains("/") || fileName.contains("\\")) {
            log.warn("Intento de path traversal bloqueado: {}", fileName);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }

        String content = TempScriptRegistry.get(fileName);

        if (content == null) {
            log.warn("Script temporal no encontrado o ya expirado: {}", fileName);
            return ResponseEntity.notFound().build();
        }

        log.debug("Sirviendo script temporal: {}", fileName);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/javascript"))
                .body(content);
    }
}