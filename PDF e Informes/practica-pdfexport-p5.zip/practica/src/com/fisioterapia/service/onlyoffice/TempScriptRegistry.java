package com.fisioterapia.service.onlyoffice;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Registro en memoria de scripts JS temporales que el OnlyOffice Document Server
 * necesita descargar vía HTTP durante la estrategia REST.
 *
 * <p>Los scripts se registran justo antes de llamar a la Conversion API
 * y se eliminan automáticamente tras 5 minutos (o manualmente al finalizar el job).
 */
public final class TempScriptRegistry {

    private TempScriptRegistry() {}

    private static final ConcurrentHashMap<String, String> STORE = new ConcurrentHashMap<>();

    private static final ScheduledExecutorService CLEANER =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "oo-script-cleaner");
                t.setDaemon(true);
                return t;
            });

    /**
     * Registra un script con su nombre de fichero como clave.
     * Se eliminará automáticamente tras 5 minutos como medida de seguridad.
     */
    public static void register(String fileName, String content) {
        STORE.put(fileName, content);
        CLEANER.schedule(() -> STORE.remove(fileName), 5, TimeUnit.MINUTES);
    }

    /**
     * Elimina manualmente el script (llamar siempre en el bloque {@code finally}).
     */
    public static void unregister(String fileName) {
        STORE.remove(fileName);
    }

    /**
     * Devuelve el contenido del script, o {@code null} si no existe.
     */
    public static String get(String fileName) {
        return STORE.get(fileName);
    }
}