package com.fisioterapia.service.onlyoffice;

/**
 * Excepción lanzada cuando OnlyOffice Document Builder
 * o la Conversion API fallan durante la generación del PDF.
 */
public class OnlyOfficeException extends RuntimeException {

    public OnlyOfficeException(String message) {
        super(message);
    }

    public OnlyOfficeException(String message, Throwable cause) {
        super(message, cause);
    }
}
