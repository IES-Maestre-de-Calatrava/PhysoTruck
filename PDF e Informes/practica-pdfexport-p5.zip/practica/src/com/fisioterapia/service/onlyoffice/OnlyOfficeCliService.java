package com.fisioterapia.service.onlyoffice;

import com.fisioterapia.config.OnlyOfficeProperties;
import com.fisioterapia.model.Paciente;
import com.fisioterapia.model.SemanaRehabilitacion;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Genera el PDF invocando el ejecutable {@code documentbuilder} de OnlyOffice
 * instalado en el servidor (estrategia <b>CLI</b>).
 *
 * <h3>Requisito</h3>
 * <p>OnlyOffice Document Builder debe estar instalado:
 * <pre>
 * # Ubuntu / Debian
 * apt-get install onlyoffice-documentbuilder
 *
 * # La ruta por defecto del ejecutable es:
 * /usr/bin/documentbuilder
 * </pre>
 *
 * <h3>Flujo</h3>
 * <ol>
 *   <li>Genera el script JS con {@link OnlyOfficeScriptBuilderService}.</li>
 *   <li>Escribe el script en un fichero temporal.</li>
 *   <li>Llama a {@code documentbuilder &lt;script.js&gt;} con {@link ProcessBuilder}.</li>
 *   <li>Lee el PDF de salida y lo devuelve como {@code byte[]}.</li>
 *   <li>Limpia los ficheros temporales.</li>
 * </ol>
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OnlyOfficeCliService {

    private final OnlyOfficeProperties      props;
    private final OnlyOfficeScriptBuilderService scriptBuilder;

    /**
     * Genera el informe PDF usando el CLI de OnlyOffice Document Builder.
     *
     * @return bytes del PDF generado
     * @throws IOException          si hay error de E/S con los ficheros temporales
     * @throws InterruptedException si el proceso es interrumpido
     * @throws OnlyOfficeException  si el proceso finaliza con error
     */
    public byte[] generarPdf(Paciente paciente,
                              List<SemanaRehabilitacion> semanas)
            throws IOException, InterruptedException {

        // ── 1. Crear directorio temporal único ────────────────────────────────
        String jobId = UUID.randomUUID().toString();
        Path   tmpDir      = Files.createTempDirectory("fisio-oo-" + jobId);
        Path   scriptPath  = tmpDir.resolve("informe.js");
        Path   outputPath  = tmpDir.resolve("informe.pdf");

        log.debug("Job {} — tmpDir: {}", jobId, tmpDir);

        try {
            // ── 2. Generar el script JS ───────────────────────────────────────
            String script = scriptBuilder.generarScript(
                    paciente, semanas, outputPath.toAbsolutePath().toString());

            Files.writeString(scriptPath, script, StandardCharsets.UTF_8);
            log.debug("Job {} — script JS escrito ({} bytes)", jobId, script.length());

            // ── 3. Ejecutar documentbuilder ───────────────────────────────────
            ejecutarBuilder(jobId, scriptPath);

            // ── 4. Verificar y leer el PDF resultante ─────────────────────────
            if (!Files.exists(outputPath)) {
                throw new OnlyOfficeException(
                        "El PDF no fue generado. Verifica que documentbuilder esté instalado " +
                        "y que el script sea válido. Job: " + jobId);
            }

            byte[] pdfBytes = Files.readAllBytes(outputPath);
            log.info("Job {} — PDF generado correctamente ({} bytes)", jobId, pdfBytes.length);
            return pdfBytes;

        } finally {
            // ── 5. Limpiar ficheros temporales siempre ────────────────────────
            limpiarDirectorioTemp(tmpDir);
        }
    }

    // ── Ejecución del proceso ──────────────────────────────────────────────────

    private void ejecutarBuilder(String jobId, Path scriptPath)
            throws IOException, InterruptedException {

        String builderExe = props.getCli().getBuilderPath();
        int    timeout    = props.getCli().getTimeoutSeconds();

        ProcessBuilder pb = new ProcessBuilder(builderExe, scriptPath.toString())
                .redirectErrorStream(true);

        // Heredar variables de entorno del proceso padre (necesario en algunos SO)
        pb.environment().putAll(System.getenv());

        log.info("Job {} — ejecutando: {} {}", jobId, builderExe, scriptPath);

        Process process = pb.start();

        // Capturar stdout/stderr para logging
        String salida = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

        boolean terminado = process.waitFor(timeout, TimeUnit.SECONDS);

        if (!terminado) {
            process.destroyForcibly();
            throw new OnlyOfficeException(
                    "Timeout: documentbuilder superó " + timeout + "s. Job: " + jobId);
        }

        int exitCode = process.exitValue();
        log.debug("Job {} — exitCode={} salida:\n{}", jobId, exitCode, salida);

        if (exitCode != 0) {
            throw new OnlyOfficeException(
                    "documentbuilder terminó con código " + exitCode +
                    ". Salida:\n" + salida + "\nJob: " + jobId);
        }
    }

    // ── Limpieza ───────────────────────────────────────────────────────────────

    private void limpiarDirectorioTemp(Path dir) {
        try {
            if (Files.exists(dir)) {
                // Borrar recursivamente (sólo los ficheros que creamos)
                try (var stream = Files.walk(dir)) {
                    stream.sorted(java.util.Comparator.reverseOrder())
                          .forEach(p -> {
                              try { Files.deleteIfExists(p); }
                              catch (IOException e) { log.warn("No se pudo borrar: {}", p); }
                          });
                }
            }
        } catch (IOException e) {
            log.warn("Error limpiando directorio temporal: {}", dir, e);
        }
    }
}
