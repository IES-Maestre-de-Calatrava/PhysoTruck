package com.fisioterapia.service.onlyoffice;

import com.fisioterapia.model.Ejercicio;
import com.fisioterapia.model.Paciente;
import com.fisioterapia.model.SemanaRehabilitacion;
import com.fisioterapia.model.Sesion;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Genera el script JavaScript para la <b>OnlyOffice Document Builder API</b>.
 *
 * <p>El script resultante se ejecuta con el comando:
 * <pre>documentbuilder /tmp/script_xxx.js</pre>
 *
 * <p>Referencias de la API:
 * <a href="https://api.onlyoffice.com/docbuilder/basic">Document Builder Basic</a> y
 * <a href="https://api.onlyoffice.com/docbuilder/global">Global API</a>.
 */
@Service
public class OnlyOfficeScriptBuilderService {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // Colores corporativos (RGB como enteros separados para la API JS)
    private static final String COLOR_PRIMARY   = "0, 102, 153";
    private static final String COLOR_SECONDARY = "0, 153, 153";
    private static final String COLOR_HEADER_BG = "229, 244, 255";
    private static final String COLOR_ALT_ROW   = "244, 250, 255";
    private static final String COLOR_WHITE     = "255, 255, 255";
    private static final String COLOR_WARN_BG   = "255, 252, 220";

    // ── Punto de entrada ───────────────────────────────────────────────────────

    /**
     * Devuelve el script JS completo listo para ser escrito a un fichero temporal
     * y ejecutado con {@code documentbuilder}.
     *
     * @param paciente datos del paciente
     * @param semanas  semanas filtradas que deben aparecer en el informe
     * @param outputPath ruta absoluta donde el builder debe escribir el PDF de salida
     */
    public String generarScript(Paciente paciente,
                                 List<SemanaRehabilitacion> semanas,
                                 String outputPath) {
        var sb = new StringBuilder();

        encabezadoScript(sb);
        abrirDocumento(sb);
        agregarPortada(sb, paciente, semanas.size());
        agregarDatosPaciente(sb, paciente);

        for (SemanaRehabilitacion semana : semanas) {
            agregarSemana(sb, semana);
        }

        agregarPie(sb);
        cerrarDocumento(sb, outputPath);

        return sb.toString();
    }

    // ── Secciones del script ───────────────────────────────────────────────────

    private void encabezadoScript(StringBuilder sb) {
        sb.append("// ============================================================\n");
        sb.append("// Informe de Rehabilitación — generado por FisioApp\n");
        sb.append("// Script para OnlyOffice Document Builder API\n");
        sb.append("// ============================================================\n\n");
    }

    private void abrirDocumento(StringBuilder sb) {
        sb.append("builder.CreateFile(\"docx\");\n");
        sb.append("var oDoc  = Api.GetDocument();\n");
        sb.append("var oLast = oDoc.GetElement(0); // párrafo vacío inicial\n\n");

        // Configurar márgenes del documento (en mm × 36000)
        sb.append("var oDocPr = oDoc.GetDefaultParaPr();\n");
        sb.append("var oSec   = oDoc.GetFinalSection();\n");
        sb.append("oSec.SetPageMargins(1800, 1440, 1800, 1440);\n\n");  // top,right,bottom,left (en EMU / 360)
    }

    private void agregarPortada(StringBuilder sb, Paciente p, int numSemanas) {
        // Banda azul superior — simulada con un párrafo sombreado
        pushParrafoConFormato(sb, "PLAN DE REHABILITACIÓN",
                "Heading1", COLOR_PRIMARY, 28, true, "center");
        pushParrafoConFormato(sb, "Informe de seguimiento fisioterapéutico",
                null, COLOR_SECONDARY, 13, false, "center");
        pushParrafoConFormato(sb,
                "Paciente: " + esc(p.getNombreCompleto()) + "  ·  Semanas incluidas: " + numSemanas,
                null, "128, 128, 128", 10, false, "center");
        pushParrafoVacio(sb);
    }

    private void agregarDatosPaciente(StringBuilder sb, Paciente p) {
        pushParrafoConFormato(sb, "DATOS DEL PACIENTE",
                "Heading2", COLOR_PRIMARY, 14, true, "left");

        // Tabla 2 × 3 con datos básicos
        int cols = 4;
        int rows = (p.getObservaciones() != null && !p.getObservaciones().isBlank()) ? 3 : 2;

        sb.append("var oTblPaciente = Api.CreateTable(").append(cols).append(", ").append(rows).append(");\n");
        sb.append("oTblPaciente.SetWidth(\"percent\", 100);\n");
        sb.append("oTblPaciente.SetTableLook(true, true, true, true, false, false);\n\n");

        // Fila 1
        celdaTabla(sb, "oTblPaciente", 0, 0, "Paciente",          true,  COLOR_HEADER_BG, COLOR_PRIMARY);
        celdaTabla(sb, "oTblPaciente", 0, 1, esc(p.getNombreCompleto()), false, COLOR_WHITE, "0,0,0");
        celdaTabla(sb, "oTblPaciente", 0, 2, "DNI",               true,  COLOR_HEADER_BG, COLOR_PRIMARY);
        celdaTabla(sb, "oTblPaciente", 0, 3, nvl(p.getDni()),     false, COLOR_WHITE, "0,0,0");

        // Fila 2
        celdaTabla(sb, "oTblPaciente", 1, 0, "Diagnóstico",       true,  COLOR_HEADER_BG, COLOR_PRIMARY);
        celdaTabla(sb, "oTblPaciente", 1, 1, nvl(p.getDiagnostico()), false, COLOR_WHITE, "0,0,0");
        celdaTabla(sb, "oTblPaciente", 1, 2, "Teléfono",          true,  COLOR_HEADER_BG, COLOR_PRIMARY);
        celdaTabla(sb, "oTblPaciente", 1, 3, nvl(p.getTelefono()), false, COLOR_WHITE, "0,0,0");

        // Fila 3 — observaciones (colspan manual: repetimos en 4 celdas)
        if (rows == 3) {
            celdaTabla(sb, "oTblPaciente", 2, 0, "Observaciones",     true,  COLOR_HEADER_BG, COLOR_PRIMARY);
            celdaTablaMulticol(sb, "oTblPaciente", 2, 1, nvl(p.getObservaciones()), 3);
        }

        sb.append("oDoc.Push(oTblPaciente);\n");
        pushParrafoVacio(sb);
    }

    private void agregarSemana(StringBuilder sb, SemanaRehabilitacion semana) {
        // Título de semana
        String rango = "";
        if (semana.getFechaInicio() != null && semana.getFechaFin() != null) {
            rango = "  (" + semana.getFechaInicio().format(FMT)
                  + " – " + semana.getFechaFin().format(FMT) + ")";
        }
        pushParrafoConFormato(sb,
                "SEMANA " + semana.getNumeroSemana() + rango,
                "Heading2", COLOR_PRIMARY, 13, true, "left");

        // Objetivo
        if (semana.getObjetivo() != null && !semana.getObjetivo().isBlank()) {
            pushParrafoConFormato(sb,
                    "Objetivo: " + esc(semana.getObjetivo()),
                    null, COLOR_SECONDARY, 10, false, "left");
        }

        // Sesiones
        if (semana.getSesiones() != null) {
            for (Sesion sesion : semana.getSesiones()) {
                agregarSesion(sb, sesion);
            }
        }

        // Notas del fisio
        if (semana.getNotasFisio() != null && !semana.getNotasFisio().isBlank()) {
            pushParrafoConFormato(sb,
                    "Notas del fisioterapeuta: " + esc(semana.getNotasFisio()),
                    null, "160, 100, 0", 9, false, "left");
        }

        pushParrafoVacio(sb);
    }

    private void agregarSesion(StringBuilder sb, Sesion sesion) {
        String titulo = "Sesión " + sesion.getNumeroSesion();
        if (sesion.getFecha() != null) {
            titulo += "  —  " + sesion.getFecha().format(FMT);
        }
        if (sesion.getDuracionMinutos() > 0) {
            titulo += "  (" + sesion.getDuracionMinutos() + " min)";
        }

        pushParrafoConFormato(sb, titulo, "Heading3", COLOR_SECONDARY, 11, true, "left");

        // Observaciones de la sesión
        if (sesion.getObservaciones() != null && !sesion.getObservaciones().isBlank()) {
            pushParrafoConFormato(sb,
                    "Obs: " + esc(sesion.getObservaciones()),
                    null, "100, 100, 100", 9, false, "left");
        }

        // Tabla de ejercicios
        if (sesion.getEjercicios() != null && !sesion.getEjercicios().isEmpty()) {
            agregarTablaEjercicios(sb, sesion.getEjercicios());
        }

        pushParrafoVacio(sb);
    }

    private void agregarTablaEjercicios(StringBuilder sb, List<Ejercicio> ejercicios) {
        int numFilas = ejercicios.size() + 1; // +1 cabecera
        String varTbl = "oTblEj" + System.nanoTime() % 10000; // nombre de var único

        sb.append("var ").append(varTbl).append(" = Api.CreateTable(5, ").append(numFilas).append(");\n");
        sb.append(varTbl).append(".SetWidth(\"percent\", 100);\n\n");

        // Cabecera
        String[] headers = {"Ejercicio", "Series", "Reps", "Intensidad", "Descripción"};
        for (int c = 0; c < headers.length; c++) {
            celdaTabla(sb, varTbl, 0, c, headers[c], true, COLOR_HEADER_BG, COLOR_PRIMARY);
        }

        // Filas de datos
        for (int i = 0; i < ejercicios.size(); i++) {
            Ejercicio ej  = ejercicios.get(i);
            String    bg  = (i % 2 == 0) ? COLOR_WHITE : COLOR_ALT_ROW;
            String    bgI = colorIntensidad(ej.getIntensidad());

            celdaTabla(sb, varTbl, i + 1, 0, esc(ej.getNombre()),               false, bg, "0,0,0");
            celdaTabla(sb, varTbl, i + 1, 1, String.valueOf(ej.getSeries()),     false, bg, "0,0,0");
            celdaTabla(sb, varTbl, i + 1, 2, String.valueOf(ej.getRepeticiones()), false, bg, "0,0,0");
            celdaTabla(sb, varTbl, i + 1, 3, nvl(ej.getIntensidad()),            true,  bgI, "0,0,0");
            celdaTabla(sb, varTbl, i + 1, 4, nvl(ej.getDescripcion()),           false, bg, "0,0,0");
        }

        sb.append("oDoc.Push(").append(varTbl).append(");\n\n");
    }

    private void agregarPie(StringBuilder sb) {
        pushParrafoVacio(sb);
        pushParrafoConFormato(sb,
                "Documento generado automáticamente — " +
                java.time.LocalDate.now().format(FMT) +
                " · Uso exclusivo del equipo clínico",
                null, "150, 150, 150", 8, false, "center");
    }

    private void cerrarDocumento(StringBuilder sb, String outputPath) {
        sb.append("\n// Guardar como PDF\n");
        sb.append("builder.SaveFile(\"pdf\", \"").append(outputPath.replace("\\", "\\\\")).append("\");\n");
        sb.append("builder.CloseFile();\n");
    }

    // ── Helpers de script ──────────────────────────────────────────────────────

    /** Añade un párrafo formateado al documento. */
    private void pushParrafoConFormato(StringBuilder sb,
                                        String texto,
                                        String estilo,
                                        String colorRGB,
                                        int tamanoFuente,
                                        boolean negrita,
                                        String alineacion) {
        String varPar = "oPar" + System.nanoTime() % 100000;
        String varRun = "oRun" + System.nanoTime() % 100000;

        sb.append("var ").append(varPar).append(" = Api.CreateParagraph();\n");
        if (estilo != null) {
            sb.append(varPar).append(".SetStyle(\"").append(estilo).append("\");\n");
        }
        sb.append(varPar).append(".SetJc(\"").append(alineacion).append("\");\n");

        sb.append("var ").append(varRun).append(" = Api.CreateRun();\n");
        sb.append(varRun).append(".AddText(\"").append(texto).append("\");\n");
        sb.append(varRun).append(".SetFontSize(").append(tamanoFuente * 2).append(");\n"); // API usa semipuntos
        sb.append(varRun).append(".SetBold(").append(negrita).append(");\n");
        sb.append(varRun).append(".SetColor(").append(colorRGB).append(");\n");
        sb.append(varPar).append(".AddElement(").append(varRun).append(");\n");
        sb.append("oDoc.Push(").append(varPar).append(");\n\n");
    }

    /** Párrafo vacío para separación. */
    private void pushParrafoVacio(StringBuilder sb) {
        sb.append("oDoc.Push(Api.CreateParagraph());\n");
    }

    /** Rellena una celda de tabla con texto y formato. */
    private void celdaTabla(StringBuilder sb,
                             String varTabla, int fila, int col,
                             String texto, boolean negrita,
                             String bgColorRGB, String fgColorRGB) {
        String varCell = "oCell_" + fila + "_" + col + "_" + System.nanoTime() % 1000;
        String varPar  = "oCellPar_" + fila + "_" + col + "_" + System.nanoTime() % 1000;
        String varRun  = "oCellRun_" + fila + "_" + col + "_" + System.nanoTime() % 1000;

        sb.append("var ").append(varCell).append(" = ").append(varTabla)
          .append(".GetCell(").append(fila).append(", ").append(col).append(");\n");
        sb.append(varCell).append(".SetShd(\"clear\", ").append(bgColorRGB).append(");\n");

        sb.append("var ").append(varPar).append(" = ").append(varCell)
          .append(".GetContent().GetElement(0);\n");

        sb.append("var ").append(varRun).append(" = Api.CreateRun();\n");
        sb.append(varRun).append(".AddText(\"").append(texto).append("\");\n");
        sb.append(varRun).append(".SetFontSize(18);\n");  // 9pt × 2
        sb.append(varRun).append(".SetBold(").append(negrita).append(");\n");
        sb.append(varRun).append(".SetColor(").append(fgColorRGB).append(");\n");
        sb.append(varPar).append(".AddElement(").append(varRun).append(");\n\n");
    }

    /** Celda que ocupa varias columnas (OnlyOffice no tiene colspan directo; rellenamos todas). */
    private void celdaTablaMulticol(StringBuilder sb,
                                     String varTabla, int fila, int colInicio,
                                     String texto, int numCols) {
        // Ponemos el texto en la primera celda y borramos las siguientes
        celdaTabla(sb, varTabla, fila, colInicio, texto, false, COLOR_WHITE, "0,0,0");
        for (int c = colInicio + 1; c < colInicio + numCols; c++) {
            celdaTabla(sb, varTabla, fila, c, "", false, COLOR_WHITE, "0,0,0");
        }
    }

    private String colorIntensidad(String intensidad) {
        if (intensidad == null) return "200, 230, 200";
        return switch (intensidad.toUpperCase()) {
            case "ALTA"  -> "255, 160, 160";
            case "MEDIA" -> "255, 220, 150";
            default      -> "180, 230, 180";
        };
    }

    /** Escapa caracteres problemáticos para strings JS. */
    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", " ")
                .replace("\r", "");
    }

    private String nvl(String s) { return s != null ? s : "—"; }
}