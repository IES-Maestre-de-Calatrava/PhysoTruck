package com.fisioterapia.service.onlyoffice;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fisioterapia.config.OnlyOfficeProperties;
import com.fisioterapia.model.Paciente;
import com.fisioterapia.model.SemanaRehabilitacion;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.UUID;

/**
 * Genera el PDF usando la <b>OnlyOffice Conversion API REST</b> del Document Server.
 *
 * <h3>Flujo</h3>
 * <ol>
 *   <li>Genera el script JS y lo guarda en un fichero temporal accesible por HTTP.</li>
 *   <li>Llama a {@code POST /ConvertService.ashx} pasando la URL del script y el
 *       formato de salida {@code pdf}.</li>
 *   <li>Descarga el PDF desde la URL que devuelve el servidor.</li>
 *   <li>Limpia los temporales.</li>
 * </ol>
 *
 * <h3>Requisito</h3>
 * <p>Un OnlyOffice Document Server accesible en red (Docker, cloud, on-premise).
 * <pre>
 * docker run -d -p 8080:80 onlyoffice/documentserver
 * </pre>
 *
 * <p>Configuración en application.properties:
 * <pre>
 * onlyoffice.strategy=REST
 * onlyoffice.rest.server-url=http://localhost:8080
 * onlyoffice.rest.callback-base-url=http://host.docker.internal:8090
 * onlyoffice.rest.jwt-secret=my_secret          # si JWT está habilitado
 * </pre>
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OnlyOfficeRestService {

    private final OnlyOfficeProperties           props;
    private final OnlyOfficeScriptBuilderService scriptBuilder;

    // WebClient se crea una sola vez (thread-safe y reutilizable)
    private final WebClient webClient = WebClient.builder()
            .codecs(c -> c.defaultCodecs().maxInMemorySize(20 * 1024 * 1024)) // 20 MB
            .build();

    // ── Punto de entrada ───────────────────────────────────────────────────────

    /**
     * Genera el informe PDF usando la Conversion API REST de OnlyOffice.
     *
     * @return bytes del PDF generado
     */
    public byte[] generarPdf(Paciente paciente,
                              List<SemanaRehabilitacion> semanas)
            throws IOException, InterruptedException {

        String jobId      = UUID.randomUUID().toString();
        Path   tmpDir     = Files.createTempDirectory("fisio-oo-rest-" + jobId);
        Path   scriptPath = tmpDir.resolve(jobId + ".js");

        log.debug("Job REST {} — tmpDir: {}", jobId, tmpDir);

        try {
            // ── 1. Generar script JS y escribirlo ─────────────────────────────
            //    El servidor OnlyOffice necesita descargar el fichero mediante HTTP,
            //    así que lo exponemos a través del endpoint estático integrado.
            //    En producción se puede usar un bucket S3 o cualquier URL pública.
            String scriptContenido = scriptBuilder.generarScript(
                    paciente, semanas,
                    "output.pdf"); // el servidor escribe el PDF en su tmpDir interno

            Files.writeString(scriptPath, scriptContenido, StandardCharsets.UTF_8);
            log.debug("Job REST {} — script escrito ({} bytes)", jobId, scriptContenido.length());

            // ── 2. Construir la URL pública del script ────────────────────────
            String callbackBase = props.getRest().getCallbackBaseUrl();
            String scriptUrl    = callbackBase + "/api/fisio/temp-script/" + jobId + ".js";

            // Registrar el script en el TempFileRegistry para que sea descargable
            TempScriptRegistry.register(jobId + ".js", scriptContenido);

            // ── 3. Llamar a la Conversion API ─────────────────────────────────
            String pdfUrl = llamarConversionApi(jobId, scriptUrl);
            log.info("Job REST {} — PDF disponible en: {}", jobId, pdfUrl);

            // ── 4. Descargar el PDF resultante ────────────────────────────────
            byte[] pdfBytes = descargarPdf(pdfUrl);
            log.info("Job REST {} — PDF descargado ({} bytes)", jobId, pdfBytes.length);
            return pdfBytes;

        } finally {
            TempScriptRegistry.unregister(jobId + ".js");
            limpiarDirectorioTemp(tmpDir);
        }
    }

    // ── Llamada a la Conversion API ────────────────────────────────────────────

    private String llamarConversionApi(String jobId, String scriptUrl) {

        String serverUrl = props.getRest().getServerUrl();

        ConversionRequest request = new ConversionRequest();
        request.setAsync(false);
        request.setFiletype("js");          // el script es un fichero .js para documentbuilder
        request.setKey(jobId);
        request.setOutputtype("pdf");
        request.setTitle("informe_" + jobId + ".pdf");
        request.setUrl(scriptUrl);

        log.debug("Job REST {} — POST {}/ConvertService.ashx  body={}", jobId, serverUrl, request);

        ConversionResponse response = webClient.post()
                .uri(serverUrl + "/ConvertService.ashx")
                .contentType(MediaType.APPLICATION_JSON)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(ConversionResponse.class)
                .timeout(Duration.ofSeconds(120))
                .block();

        if (response == null) {
            throw new OnlyOfficeException("La Conversion API devolvió una respuesta vacía. Job: " + jobId);
        }
        if (response.getError() != 0) {
            throw new OnlyOfficeException(
                    "Conversion API error " + response.getError() +
                    " — " + descripcionError(response.getError()) +
                    ". Job: " + jobId);
        }
        if (!response.isEndConvert()) {
            throw new OnlyOfficeException(
                    "La conversión no se completó (endConvert=false). Job: " + jobId);
        }

        return response.getFileUrl();
    }

    // ── Descarga del PDF resultante ────────────────────────────────────────────

    private byte[] descargarPdf(String pdfUrl) {
        byte[] bytes = webClient.get()
                .uri(pdfUrl)
                .retrieve()
                .bodyToMono(byte[].class)
                .timeout(Duration.ofSeconds(60))
                .block();

        if (bytes == null || bytes.length == 0) {
            throw new OnlyOfficeException("El PDF descargado desde '" + pdfUrl + "' está vacío.");
        }
        return bytes;
    }

    // ── Limpieza ───────────────────────────────────────────────────────────────

    private void limpiarDirectorioTemp(Path dir) {
        try {
            if (Files.exists(dir)) {
                try (var stream = Files.walk(dir)) {
                    stream.sorted(java.util.Comparator.reverseOrder())
                          .forEach(p -> {
                              try { Files.deleteIfExists(p); }
                              catch (IOException e) { log.warn("No se pudo borrar: {}", p); }
                          });
                }
            }
        } catch (IOException e) {
            log.warn("Error limpiando directorio temporal: {}", dir, e);
        }
    }

    // ── Descripción de códigos de error de la Conversion API ──────────────────

    private String descripcionError(int code) {
        return switch (code) {
            case -1  -> "Error desconocido";
            case -2  -> "Timeout de conversión";
            case -3  -> "Error de conversión";
            case -4  -> "Error descargando el fichero de origen";
            case -5  -> "Contraseña incorrecta";
            case -6  -> "Error accediendo a los resultados";
            case -7  -> "Formato de fichero de origen incorrecto";
            case -8  -> "Forzar conversión de fichero no permitida";
            case -9  -> "Token JWT no válido";
            default  -> "Código de error desconocido (" + code + ")";
        };
    }

    // ── DTOs para la Conversion API ────────────────────────────────────────────

    @Data
    static class ConversionRequest {
        private boolean async;
        private String  filetype;
        private String  key;
        private String  outputtype;
        private String  title;
        private String  url;
        @JsonProperty("token")
        private String  token;  // JWT opcional; se rellena si jwt-secret está configurado
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class ConversionResponse {
        @JsonProperty("endConvert")   private boolean endConvert;
        @JsonProperty("error")        private int     error;
        @JsonProperty("fileUrl")      private String  fileUrl;
        @JsonProperty("percent")      private int     percent;
    }
}
