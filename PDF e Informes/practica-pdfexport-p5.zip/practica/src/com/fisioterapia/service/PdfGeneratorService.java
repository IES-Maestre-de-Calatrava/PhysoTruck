package com.fisioterapia.service;

import com.fisioterapia.config.OnlyOfficeProperties;
import com.fisioterapia.model.Paciente;
import com.fisioterapia.model.SemanaRehabilitacion;
import com.fisioterapia.service.onlyoffice.OnlyOfficeCliService;
import com.fisioterapia.service.onlyoffice.OnlyOfficeException;
import com.fisioterapia.service.onlyoffice.OnlyOfficeRestService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

/**
 * Fachada principal de generación de PDFs.
 *
 * <p>Delega en la estrategia configurada mediante la propiedad
 * {@code onlyoffice.strategy} ({@code CLI} o {@code REST}).
 *
 * <ul>
 *   <li><b>CLI</b>  — ejecuta el binario {@code documentbuilder} localmente.</li>
 *   <li><b>REST</b> — usa la Conversion API HTTP del OnlyOffice Document Server.</li>
 * </ul>
 *
 * <p>El controlador sólo conoce esta fachada; es agnóstico a la estrategia.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PdfGeneratorService {

    private final OnlyOfficeProperties  props;
    private final OnlyOfficeCliService  cliService;
    private final OnlyOfficeRestService restService;

    /**
     * Genera el informe PDF para el paciente y las semanas indicadas.
     *
     * @param paciente datos completos del paciente
     * @param semanas  semanas filtradas que deben aparecer en el informe
     * @return bytes del PDF listo para enviar como respuesta HTTP
     * @throws IOException si ocurre un error de E/S
     */
    public byte[] generarInformeSemanal(Paciente paciente,
                                        List<SemanaRehabilitacion> semanas) throws IOException {
        try {
            return switch (props.getStrategy()) {
                case CLI  -> {
                    log.info("Generando PDF vía OnlyOffice CLI para paciente={}", paciente.getId());
                    yield cliService.generarPdf(paciente, semanas);
                }
                case REST -> {
                    log.info("Generando PDF vía OnlyOffice REST para paciente={}", paciente.getId());
                    yield restService.generarPdf(paciente, semanas);
                }
            };
        } catch (OnlyOfficeException e) {
            throw new IOException("Error generando PDF con OnlyOffice: " + e.getMessage(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Generación de PDF interrumpida", e);
        }
    }
}
