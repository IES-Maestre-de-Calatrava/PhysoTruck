package com.fisioterapia.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * Propiedades de integración con OnlyOffice leídas desde application.properties.
 *
 * <p>Soporta dos estrategias de generación de PDF:
 * <ul>
 *   <li><b>CLI</b>  — llama al ejecutable {@code documentbuilder} instalado en el servidor.</li>
 *   <li><b>REST</b> — usa la Conversion API del OnlyOffice Document Server (Docker / cloud).</li>
 * </ul>
 */
@Data
@Component
@ConfigurationProperties(prefix = "onlyoffice")
public class OnlyOfficeProperties {

    // ── Estrategia activa ──────────────────────────────────────────────────────
    /**
     * Estrategia a usar: {@code CLI} o {@code REST}.
     * Por defecto CLI (Document Builder local).
     */
    private Strategy strategy = Strategy.CLI;

    // ── Configuración CLI ──────────────────────────────────────────────────────
    private Cli cli = new Cli();

    @Data
    public static class Cli {
        /** Ruta al ejecutable documentbuilder. */
        private String builderPath = "/usr/bin/documentbuilder";

        /** Tiempo máximo de espera del proceso en segundos. */
        private int timeoutSeconds = 60;
    }

    // ── Configuración REST (Document Server) ──────────────────────────────────
    private Rest rest = new Rest();

    @Data
    public static class Rest {
        /** URL base del Document Server, p.ej. http://onlyoffice:8080 */
        private String serverUrl = "http://localhost:8080";

        /** JWT secret configurado en el Document Server (puede estar en blanco). */
        private String jwtSecret = "";

        /**
         * URL pública desde la que el Document Server puede descargar el DOCX temporal.
         * Necesario porque el Document Server descarga el fichero mediante HTTP.
         */
        private String callbackBaseUrl = "http://host.docker.internal:8080";
    }

    // ── Enum de estrategia ─────────────────────────────────────────────────────
    public enum Strategy { CLI, REST }
}