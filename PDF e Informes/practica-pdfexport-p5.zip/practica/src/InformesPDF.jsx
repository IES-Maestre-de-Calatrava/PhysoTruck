import { useState } from "react";

// ─── Datos de ejemplo ────────────────────────────────────────────────────────
const PACIENTES = [
  { id: "p1", nombre: "Ana García López" },
  { id: "p2", nombre: "Carlos Martínez Ruiz" },
  { id: "p3", nombre: "Laura Fernández Soto" },
  { id: "p4", nombre: "Miguel Torres Vega" },
  { id: "p5", nombre: "Sofía Romero Díaz" },
];

// ─── Utilidades ───────────────────────────────────────────────────────────────
function isoWeek(dateStr) {
  // Devuelve {año, semana} a partir de "YYYY-Www"
  const [year, week] = dateStr.split("-W").map(Number);
  return { year, week };
}

function semanaLabel(dateStr) {
  if (!dateStr) return "";
  const { year, week } = isoWeek(dateStr);
  return `Sem. ${week} · ${year}`;
}

// ─── Componente principal ─────────────────────────────────────────────────────
export default function InformesPDF() {
  const [pacienteId, setPacienteId] = useState("");
  const [semanaInicio, setSemanaInicio] = useState("");
  const [semanaFin, setSemanaFin] = useState("");
  const [estado, setEstado] = useState("idle"); // idle | loading | error
  const [errorMsg, setErrorMsg] = useState("");

  const paciente = PACIENTES.find((p) => p.id === pacienteId);

  const valido =
    pacienteId &&
    semanaInicio &&
    semanaFin &&
    isoWeek(semanaInicio).year * 53 + isoWeek(semanaInicio).week <=
      isoWeek(semanaFin).year * 53 + isoWeek(semanaFin).week;

  async function handleDescargar() {
    if (!valido || estado === "loading") return;
    setEstado("loading");
    setErrorMsg("");

    try {
      // ── Llamada al backend ───────────────────────────────────────────────
      // Ajusta la URL a tu endpoint real.
      const url = new URL("/api/informes/pdf", window.location.origin);
      url.searchParams.set("pacienteId", pacienteId);
      url.searchParams.set("semanaInicio", semanaInicio);
      url.searchParams.set("semanaFin", semanaFin);

      const res = await fetch(url.toString(), {
        method: "GET",
        headers: { Accept: "application/pdf" },
      });

      if (!res.ok) throw new Error(`Error del servidor: ${res.status}`);

      // ── Descarga automática ──────────────────────────────────────────────
      const blob = await res.blob();
      const objectUrl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = objectUrl;
      a.download = `informe_${pacienteId}_${semanaInicio}_${semanaFin}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(objectUrl);

      setEstado("idle");
    } catch (err) {
      setEstado("error");
      setErrorMsg(err.message || "No se pudo descargar el informe.");
    }
  }

  return (
    <>
      {/* ── Fuentes ── */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
          --bg:        #f0ede8;
          --surface:   #faf9f7;
          --border:    #ddd8d0;
          --accent:    #2d6a4f;
          --accent-lt: #52b788;
          --accent-bg: #d8f3dc;
          --txt:       #1a1a18;
          --muted:     #7a7670;
          --danger:    #c0392b;
          --danger-bg: #fdf0ee;
          --radius:    12px;
          --shadow:    0 2px 16px rgba(0,0,0,.08);
        }

        body { background: var(--bg); }

        .page {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 2rem;
          font-family: 'DM Sans', sans-serif;
          background: var(--bg);
        }

        /* ── Card ── */
        .card {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 20px;
          box-shadow: var(--shadow);
          width: 100%;
          max-width: 520px;
          overflow: hidden;
        }

        /* ── Header ── */
        .card-head {
          background: var(--accent);
          padding: 2rem 2.4rem 1.8rem;
          position: relative;
          overflow: hidden;
        }
        .card-head::after {
          content: '';
          position: absolute;
          right: -40px; bottom: -60px;
          width: 180px; height: 180px;
          border-radius: 50%;
          background: rgba(255,255,255,.06);
        }
        .card-head::before {
          content: '';
          position: absolute;
          right: 40px; bottom: -20px;
          width: 90px; height: 90px;
          border-radius: 50%;
          background: rgba(255,255,255,.08);
        }
        .head-label {
          font-size: .7rem;
          font-weight: 600;
          letter-spacing: .12em;
          text-transform: uppercase;
          color: var(--accent-lt);
          margin-bottom: .5rem;
        }
        .head-title {
          font-family: 'DM Serif Display', serif;
          font-size: 1.7rem;
          color: #fff;
          line-height: 1.2;
        }
        .head-sub {
          margin-top: .4rem;
          font-size: .82rem;
          color: rgba(255,255,255,.65);
          font-weight: 300;
        }

        /* ── Body ── */
        .card-body {
          padding: 2rem 2.4rem 2.4rem;
          display: flex;
          flex-direction: column;
          gap: 1.4rem;
        }

        /* ── Field ── */
        .field { display: flex; flex-direction: column; gap: .45rem; }
        .field-label {
          font-size: .72rem;
          font-weight: 600;
          letter-spacing: .08em;
          text-transform: uppercase;
          color: var(--muted);
        }
        .field-row { display: grid; grid-template-columns: 1fr 1fr; gap: .8rem; }

        /* ── Select / Input ── */
        select, input[type="week"] {
          width: 100%;
          padding: .7rem 1rem;
          border: 1.5px solid var(--border);
          border-radius: var(--radius);
          background: #fff;
          color: var(--txt);
          font-family: 'DM Sans', sans-serif;
          font-size: .9rem;
          font-weight: 400;
          appearance: none;
          -webkit-appearance: none;
          transition: border-color .18s, box-shadow .18s;
          outline: none;
          cursor: pointer;
        }
        select:focus, input[type="week"]:focus {
          border-color: var(--accent);
          box-shadow: 0 0 0 3px rgba(45,106,79,.15);
        }
        .select-wrap { position: relative; }
        .select-wrap::after {
          content: '▾';
          position: absolute;
          right: .9rem; top: 50%;
          transform: translateY(-50%);
          color: var(--muted);
          pointer-events: none;
          font-size: .8rem;
        }

        /* ── Preview badge ── */
        .preview {
          background: var(--accent-bg);
          border: 1px solid #b7e4c7;
          border-radius: var(--radius);
          padding: .75rem 1rem;
          font-size: .82rem;
          color: var(--accent);
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: .5rem;
          animation: fadeIn .25s ease;
        }
        .preview-dot {
          width: 6px; height: 6px;
          background: var(--accent-lt);
          border-radius: 50%;
          flex-shrink: 0;
        }

        /* ── Error ── */
        .error-box {
          background: var(--danger-bg);
          border: 1px solid #f5c6c2;
          border-radius: var(--radius);
          padding: .75rem 1rem;
          font-size: .82rem;
          color: var(--danger);
          animation: fadeIn .2s ease;
        }

        /* ── Button ── */
        .btn {
          width: 100%;
          padding: .9rem 1.2rem;
          border: none;
          border-radius: var(--radius);
          background: var(--accent);
          color: #fff;
          font-family: 'DM Sans', sans-serif;
          font-size: .95rem;
          font-weight: 600;
          letter-spacing: .02em;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: .6rem;
          transition: background .18s, transform .12s, box-shadow .18s;
          margin-top: .2rem;
        }
        .btn:hover:not(:disabled) {
          background: #236040;
          box-shadow: 0 4px 20px rgba(45,106,79,.35);
          transform: translateY(-1px);
        }
        .btn:active:not(:disabled) { transform: translateY(0); }
        .btn:disabled {
          background: #a8c5b5;
          cursor: not-allowed;
          box-shadow: none;
        }
        .btn svg { flex-shrink: 0; }

        /* ── Spinner ── */
        .spinner {
          width: 18px; height: 18px;
          border: 2.5px solid rgba(255,255,255,.4);
          border-top-color: #fff;
          border-radius: 50%;
          animation: spin .7s linear infinite;
        }

        @keyframes spin  { to { transform: rotate(360deg); } }
        @keyframes fadeIn{ from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: none; } }

        /* ── Divider ── */
        .divider {
          height: 1px;
          background: var(--border);
          border: none;
          margin: .2rem 0;
        }

        @media (max-width: 460px) {
          .card-head { padding: 1.5rem 1.4rem; }
          .card-body { padding: 1.5rem 1.4rem; }
          .field-row { grid-template-columns: 1fr; }
        }
      `}</style>

      <div className="page">
        <div className="card">
          {/* ── Cabecera ── */}
          <div className="card-head">
            <p className="head-label">Fisioterapia · Informes</p>
            <h1 className="head-title">Generar informe<br />de seguimiento</h1>
            <p className="head-sub">Selecciona paciente y período para descargar el PDF</p>
          </div>

          {/* ── Formulario ── */}
          <div className="card-body">

            {/* Paciente */}
            <div className="field">
              <label className="field-label" htmlFor="paciente">Paciente</label>
              <div className="select-wrap">
                <select
                  id="paciente"
                  value={pacienteId}
                  onChange={(e) => { setPacienteId(e.target.value); setEstado("idle"); }}
                >
                  <option value="">— Selecciona un paciente —</option>
                  {PACIENTES.map((p) => (
                    <option key={p.id} value={p.id}>{p.nombre}</option>
                  ))}
                </select>
              </div>
            </div>

            <hr className="divider" />

            {/* Semanas */}
            <div className="field">
              <label className="field-label">Período del informe</label>
              <div className="field-row">
                <div className="field">
                  <label className="field-label" htmlFor="semInicio" style={{ fontSize: ".67rem" }}>Semana inicio</label>
                  <input
                    id="semInicio"
                    type="week"
                    value={semanaInicio}
                    onChange={(e) => { setSemanaInicio(e.target.value); setEstado("idle"); }}
                  />
                </div>
                <div className="field">
                  <label className="field-label" htmlFor="semFin" style={{ fontSize: ".67rem" }}>Semana fin</label>
                  <input
                    id="semFin"
                    type="week"
                    value={semanaFin}
                    min={semanaInicio || undefined}
                    onChange={(e) => { setSemanaFin(e.target.value); setEstado("idle"); }}
                  />
                </div>
              </div>
            </div>

            {/* Preview del informe */}
            {valido && (
              <div className="preview">
                <span className="preview-dot" />
                <span>
                  <strong>{paciente?.nombre}</strong>
                  {" · "}
                  {semanaLabel(semanaInicio)} → {semanaLabel(semanaFin)}
                </span>
              </div>
            )}

            {/* Error */}
            {estado === "error" && (
              <div className="error-box">
                ⚠️ {errorMsg}
              </div>
            )}

            {/* Botón descargar */}
            <button
              className="btn"
              onClick={handleDescargar}
              disabled={!valido || estado === "loading"}
            >
              {estado === "loading" ? (
                <>
                  <span className="spinner" />
                  Generando informe…
                </>
              ) : (
                <>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 15V3"/>
                    <path d="M7 10l5 5 5-5"/>
                    <path d="M3 18h18v2a1 1 0 01-1 1H4a1 1 0 01-1-1v-2z"/>
                  </svg>
                  Descargar PDF
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}